#pragma once
#include <iostream>
using namespace std;

class Printer {
	string model, manufacturer;
	int printCount, availableCount;
protected:
	Printer(string model, string manufacturer, int availableCount);
	bool print(int pages);
	string getModel();
	string getManufacturer();
	int getAvailableCount();
}; 
class PrintInkJet :public Printer {
	int availablelink;
public:
	PrintInkJet(string model, string manufacturer, int availableCount, int availablelink);
	bool printInkJet(int pages);
	void show();
};
class PrintLaser :public Printer {
	int availableToner;
public:
	PrintLaser(string model, string manufacturer, int availbleCout, int availableToner);
	bool printLaser(int pages);
	void show();
};